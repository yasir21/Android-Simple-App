package com.quiz.quiz1.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.quiz.quiz1.R;

public class HitungLingkaran extends AppCompatActivity {
    EditText r;
    Button hitung;
    TextView hasil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lingkaran);
        r = (EditText)findViewById(R.id.jari);
        hitung = (Button) findViewById(R.id.button);
        hasil = (TextView)findViewById(R.id.txt_hasil);
        hitung.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                //jika tidak mengisi panjang dan lebar sekaligus maka akan tampil notifikasi
                if(r.length()==0){
                    Toast.makeText(getApplication(),"Jari-Jari tidak boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else{
                    String isialas = r.getText().toString();
                    double r = Double.parseDouble(isialas);
                    double phi = 3.14;
                    double hs = LuasLingkaran(r,phi);
                    String output = String.valueOf(hs);
                    hasil.setText(output.toString());
                }
            }
        });
    }
    public double LuasLingkaran(double r, double phi){return phi*r*r;}
    public void backtoMenu(View view){
        finish();
    }
}
