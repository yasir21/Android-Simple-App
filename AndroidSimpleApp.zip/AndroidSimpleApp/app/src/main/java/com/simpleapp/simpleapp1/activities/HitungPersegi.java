package com.quiz.quiz1.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.quiz.quiz1.R;

public class HitungPersegi extends AppCompatActivity {
    EditText s;
    Button hitung;
    TextView hasil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.persegi);
        s = (EditText)findViewById(R.id.sisi);
        hitung = (Button) findViewById(R.id.button);
        hasil = (TextView)findViewById(R.id.txt_hasil);
        hitung.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                //jika tidak mengisi panjang dan lebar sekaligus maka akan tampil notifikasi
                if(s.length()==0){
                    Toast.makeText(getApplication(),"Sisi tidak boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else{
                    String isialas = s.getText().toString();
                    double s = Double.parseDouble(isialas);
                    double hs = LuasLingkaran(s);
                    String output = String.valueOf(hs);
                    hasil.setText(output.toString());
                }
            }
        });
    }
    public double LuasLingkaran(double s){return s*s;}
    public void backtoMenu(View view){
        finish();
    }
}
